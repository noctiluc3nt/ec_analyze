---
title: 'Reddy: An open-source package for analyzing eddy-covariance measurements'
tags:
  - R
  - jupyter notebooks
  - eddy-covariance
  - turbulence
  - meteorology
authors:
  - name: Laura Mack
    orcid: 0009-0007-9123-2278
    affiliation: 1
affiliations:
 - name: Department of Geosciences, University of Oslo, Oslo, Norway
   index: 1
date: 05 September 2024
bibliography: paper.bib

---

# Introduction/Summary
- software from manufacturer, software not flexible, not easily adaptable -> Reddy modular structure, customizable post-processing and analysis
- aim: quick, but advanced and reproducible analysis of EC measurements in the field; accompanied by gitbook for teaching/documentation
- combination of different methods: spectra, anisotropy analysis, quadrant analysis, flux footprint, surface energy balance closure

# Statement of Need

 Research enabled by Reddy:

# Overview and Functionality


Documentation: 
- follows CRAN standards
- documentation build with Roxygen2

# State of the Field



# Conclusion





# Citations

Citations to entries in paper.bib should be in
[rMarkdown](http://rmarkdown.rstudio.com/authoring_bibliographies_and_citations.html)
format.

If you want to cite a software repository URL (e.g. something on GitHub without a preferred
citation) then you can do it with the example BibTeX entry below for @fidgit.

For a quick reference, the following citation commands can be used:
- `@author:2001`  ->  "Author et al. (2001)"
- `[@author:2001]` -> "(Author et al., 2001)"
- `[@author1:2001; @author2:2001]` -> "(Author1 et al., 2001; Author2 et al., 2002)"

# Figures

Figures can be included like this:
![Caption for example figure.\label{fig:example}](figure.png)
and referenced from text using \autoref{fig:example}.

Figure sizes can be customized by adding an optional second parameter:
![Caption for example figure.](figure.png){ width=20% }

# Acknowledgements

# References