---
title: 'Reddy: An open-source package for analyzing eddy-covariance measurements'
tags:
  - eddy-covariance
  - turbulence
  - land-atmosphere exchange
  - meteorology
  - R
  - jupyter notebooks
authors:
  - name: Laura Mack
    orcid: 0009-0007-9123-2278
    affiliation: 1
affiliations:
 - name: Department of Geosciences, University of Oslo, Oslo, Norway
   index: 1
date: 13 September 2024
bibliography: paper.bib

---

# Introduction
Eddy-covariance (EC) measurements represent the standard approach for automated long-term observations of turbulent exchange processes between the atmosphere and the underlying surface, which play an essential role in the interaction of the atmosphere with vegetation, hydrology or cryosphere. The raw EC data has to be post-processed and quality controlled tailored to the desired scientific analysis. Subsequent scientific evaluation can include the calculation and visualization of turbulence diagnostics, spectra, quadrant analysis, anisotropy analysis or flux footprints, as well as a general contextualization with meteorological and radiative measurements. The Reddy package includes all these steps and thus allows for a fast and reproducible analysis of EC measurements by combining approaches from meteorology and environmental sciences. By using this modular open-source R-package, users are independent of manufacturer's software and can fully customize the post-processing of the EC measurements to suit their applications. The Reddy package is written following the CRAN standards (The Comprehensive R Archive Network, https://cran.r-project.org/) and contains a detailed documentation in a separate gitbook (https://noctiluc3nt.github.io/ec_analyze/), which can also be used in teaching, as it not only introduces the software, but also the background of the implemented methods as well as the technical setup of the EC instrumentation.


# Statement of Need
EC instruments are usually supplied with manufacturer software for post-processing the raw EC measurements. This software is often not transparant and only allows limited customization of the post-processing routine. However, a scientific analysis of EC measurements has to be fully comprehensible and tailored to the desired application. For example, analysing the dynamics of stable boundary layer flows requires a different post-processing and averaging time than for fully-developed turbulence under unstable stratification. In addition, advanced analysis methods may require output parameters that are not provided by the manufacturer software. For example, the anisotropy analysis of turbulence requires knowledge of lateral momentum fluxes, which are usually not part of the post-processing in the manufacturer's software. For some flow conditions it is also of interest to analyse the high-frequency measurements directly, e.g. with quadrant analysis. The Reddy package is modular, allowing for fully customizable post-processing, where quality control, averaging time and applied correction method can be adapted as scientifically required. <br>
The field of land-atmosphere interactions is highly interdiscplinary, so that different methods have been developed in different research areas, e.g. meteorology, hydrology or ecology. However, a comprehensive analysis of an EC sites always requires a combination of different methodological approaches. The Reddy package combines EC-based methods derived from more theoretical meteorological turbulence studies, such as multiresolution decomposition or invariant analysis of the Reynolds stress tensor, with methods from ecohydrology, such as footprint analysis or the surface energy framework, and enables the derivation of various diagnostics, such as friction velocity, stability measures or evaporative fraction.
The structure and functionality of the Reddy package enable both a quick in-field analysis and an in-depth scientific analysis. For example, @Mack2024 used the Reddy package for analysing turbulence characteristics at a heterogeneous alpine tundra site by combining quadrant analysis, multiresolution decomposition and anisotropy analysis to explain how coherent structures cause deviations from classical turbulence theories. <br>
In addition, the Reddy package is accompanied by a gitbook (https://noctiluc3nt.github.io/ec_analyze/), which explains the setup of an EC site, the post-processing and the analysis methods, and thus can be used as basis for university-level teaching of the EC methodology, especially in combination with field trips.


# Functionality
The Reddy package is an R-package [@R2021] following the CRAN standards (The Comprehensive R Archive Network, https://cran.r-project.org/) and the package documentation is written utilizing the library roxygen2 (https://roxygen2.r-lib.org/). The package can be installed directly from github through `devtools::install_git("https://github.com/noctiluc3nt/Reddy")`. An accompanying gitbook (https://noctiluc3nt.github.io/ec_analyze/) provides more background information about the methods and instrumentation, which enables a smooth and language-independent introduction to EC post-processing and analysis methods. The gitbook is divided into several subchapters, which are also available as jupyter notebooks and serve as an orientation for a consecutive combination of the functions available in Reddy. <br>
The package is splitted into several parts, which are summarized in figure {fig:overview}: The first step is the raw data post-processing, for which the Reddy package contains several separate functions (e.g. despiking, lag-time correction, coordinate rotations, time averaging, WPL correction, SND correction, unit conversions, quality flagging, gap-filling), from which the user can compile a customized post-processing chain. <br>
Based on the averaged EC data, various turbulence diagnostics (e.g turbulence intensity or stability parameter) can be calculated, an anisotropy analysis with plotting a barycentric map [@Banerjee2007] and a flux footprint estimation [@Kljun2015] can be performed. The calculation of spectra based on different methods, e.g. averaged Fast Fourier transform (FFT) spectrum or multiresolution decomposition (MRD) [@Vickers2003] and quadrant analysis [@Mack2024] can be applied to the high-frequency measurements directly to gain insights into spectral separation between turbulent and submeso-scale motions as well as the contributing coherent structures. <br>
Since eddy-covariance measurements allow to derive the actual flux, they can be used to test classical turbulence closure (e.g. bulk closures or down-gradient eddy-diffusivity closures),  that are often used to couple the land and atmospheric model components in a numerical weather or climate prediction model. The Reddy package provides for this ancillary function, that allow an easy binning based on the stability parameter, and to compare them with scaling functions in flux-variance or flux-profile relations from the literature, e.g. @Cuxart2006. <br>
The calculated turbulent fluxes can be used to derive hydrological measures (e.g. Bowen ratio or evaporative fraction) or calculated the surface energy balance closure [@Mauder2020] by combining them with radiative flux measurements, for which the Reddy package contains dedicated functions. For general meteorological contextualization, the Reddy package contains functions to calculated wind-related quantities (e.g. gust factor) or the clear-sky index as well as functions for unit conversions.

![Overview of the functionality of the Reddy package.\label{fig:overview}](schema.png)


# State of the Field
Multiple other packages for eddy-covariance data processing exist with different applications and different degrees of specialization as well as in different languages. The main focus of these packages, however, is the post-processing of raw eddy-covariance data (often as wrapper of manufacturer software) and long-term ecosystem monitoring studies, as summarized below. 
In this regard, [Reddy](https://github.com/noctiluc3nt/Reddy) fills a gap, as it additionally considers turbulence theoretical and meteorological applications and allows for a fully customized post-processing and analysis of eddy-covariance data. <br>

- [EddyPro®](https://github.com/LI-COR-Environmental/eddypro-engine) (Fortran): Post-processing of eddy-covariance data from the manufacturer LI-COR Biosciences.
- [ONEFlux](https://github.com/fluxnet/ONEFlux) (C): Post-processing of (half-)hourly eddy-covariance data used to create the FLUXNET2015 dataset ("Open Network-Enabled Flux processing pipeline") [@Pastorello2020].
- [REddyProc](https://cran.r-project.org/web/packages/REddyProc/index.html) (R): Post-processing of (half-)hourly eddy-covariance measurements.
- [openeddy](https://github.com/lsigut/openeddy) (R): Post-processing of eddy-covariance data, aligned with REddyProc.
- [RFlux](https://github.com/domvit81/RFlux/) (R): GUI for post-processing of eddy-covariance raw data by calling EddyPro®.
- [eddy4R](https://github.com/NEONScience/eddy4R) (R): Family of several R-package for eddy-covariance post-processing in a DevOps framework [@Metzger2017].
- [icoscp](https://pypi.org/project/icoscp/) (Python): Access to data from ICOS (Integrated Carbon Observation System) data portal.
- [flux-data-qaqc](https://github.com/Open-ET/flux-data-qaqc) (Python): Post-processing of eddy-covariance measurements to derive daily or monthly evapotranspiration in a energy balance framework [@Volk2021].


# Conclusion
The Reddy package is a modular R-package that allows for a fully customized post-processing of raw eddy-covariance data as well as detailed analyses, combining methods from turbulence theory, meteorology and ecohydrology. The package can be used for a near-real time in-field analysis of EC measurements, an in-depth scientific analysis, or for teaching in micrometeorological courses based on the accompanied gitbook (https://noctiluc3nt.github.io/ec_analyze/).




# References