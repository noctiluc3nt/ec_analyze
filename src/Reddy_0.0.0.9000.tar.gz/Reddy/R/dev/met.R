#' Saturation vapor pressure over water
#'
#'@description Calculates the saturation vapor pressure over water for given temperature and pressure
#'@param temp scalar or vector, temperature [K]
#'@param pres scalar or vector, pressure [Pa]
#'@return E_s, saturation vapor pressure over water
#'@export
#'
#'@examples
#'series=c(1,3,2,5,1,2,1,3)
#'mrd(series)
#'
calc_satvaporpressure = function(temp,pres) {
    #@param: T temperature in K
    #@param: p pressure in Pa
    #@return: e_s saturation vapor pressure over water
    es0 <- 611.21
    T0 <- 273.15
    a3l <- 17.502
    a4l <- 32.19
    return(es0 * exp( a3l * (temp - T0) / (T - a4l) ))
}


#' Clear Sky Index (CSI)
#'
#'@description Calculates clear sky index
#'@param temp scalar or vector, temperature [K]
#'@param lwin scalar or vector, longwave incoming radiation [W/m^2]
#'@param rh scalar or vector, relative humidity [%]
#'@param e scalar or vector, vapor pressure [Pa]
#'@param pres scalar or vector, pressure [Pa]
#'@return CSI, clear sky index
#'@export
#'
calc_csi = function(temp,lwin,rh=NULL,e=NULL) {
    #TODO pressure for rh case
    if (is.null(rh) & is.null(e)) {
        print("ERROR: Either relative himidty rh or vapor pressure e have to be passed.")
    }
    if (!is.null(rh)) { #calculate vapor pressure
        es = calc_satvaporpressure(temp,pres)
        e = rh * es/100
    }
    epsilon_A = lwin/(sigma()*temp) #actual atmospheric emissivity
    epsilon = 0.23 + 0.47*(e/temp)^(1/8) #(theoretical) clear sky emissivity, Marty and Philiponna, 2002
    return(epsilon_A/epsilon)
}