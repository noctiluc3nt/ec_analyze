#' Reference Class: Flux Footprint
#'
#'@import methods
#'@export
#'@exportClass generateFluxFootprint
#'
generateFluxFootprint = setRefClass("FluxFootprint",fields=c(
    "xcontour"=list,
    "ycontour"=list,
    "xmax"=numeric,
    "x"=array,
    "y"=array,
    "x2d"=array,
    "y2d"=array,
    "f2d"=array
))


#' Class: Invariant Analysis of Reynolds Stress Tensor
#'
#'@import methods
#'@export
#'@exportClass generateInvariantAnalysis
#'
generateInvariantAnalyis = setRefClass("InvariantAnalysis",fields=c(
    "xb"=numeric,
    "yb"=numeric,
    "eta"=numeric,
    "xi"=numeric
))



#' Class: Quadrant Analysis
#'
#'@import methods
#'@export
#'@exportClass generateQuadrantAnalysis
#'
generateQuadrantAnalysis = setRefClass("QuadrantAnalysis",fields=c(
    "occurrence"=array,
    "strength_product"=array,
    "strength_cov"=array,
    "hole_sizes"=array
))

