### Reddy package ###
#'
#' Introduction
#' @name Reddy package
#' @docType package
#' @description EC postprocessing and analysis
#' @details to be detailed
#' @references
#' * Mack, L., Berntsen, T.K., Vercauteren, N., Pirk, N. (2024). Transfer Efficiency and Organization in Turbulent Transport over Alpine Tundra. Boundary-Layer Meteorology 190, 38. doi: https://doi.org/10.1007/s10546-024-00879-5
#' @md
NULL