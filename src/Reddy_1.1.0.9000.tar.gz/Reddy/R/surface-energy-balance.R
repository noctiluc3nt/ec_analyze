#' Plotting of surface energy balance and calculation of surface energy balance unclosure
#'
#'@description Plotting of surface energy balance and calculation of surface energy balance unclosure as residual flux and closure ratio
#'@param sw_in incoming shortwave radiation [W/m^2] (as vector of time)
#'@param sw_out outgoing shortwave radiation [W/m^2] (as vector of time)
#'@param lw_in incoming longwave radiation [W/m^2] (as vector of time)
#'@param lw_out outgoing longwave radiation [W/m^2] (as vector of time)
#'@param sh sensible heat flux [W/m^2] (as vector of time) -- if measured
#'@param lh latent heat flux [W/m^2] (as vector of time) -- if measured
#'@param gh ground heat flux [W/m^2] (as vector of time) -- if measured
#'@param time_vector times used as x-axis labels (optional)
#'@param print_fit should the fit summary be printed? default: \code{print_fit=TRUE}
#'@param ... optional plot parameters
#' 
#'@return no return
#'@export
#'
plot_seb = function(sw_in,sw_out,lw_in,lw_out,sh=NULL,lh=NULL,gh=NULL,time_vector=NULL,print_fit=TRUE,...) {
    #check which fluxes are given
    n=length(sw_in)
    if (is.null(sh)) sh = rep(0,n)
    if (is.null(lh)) lh = rep(0,n)
    if (is.null(gh)) gh = rep(0,n)
    #balances
    rad_balance = sw_in-sw_out+lw_in-lw_out #radiation balance
    seb_balance = rad_balance-gh-sh-lh #surface energy balance (residual flux)
    cr = (sh+lh)/(rad_balance-gh) #closure ratio
    #plot
    if (is.null(time_vector)) time_vector = 1:n
    #if (!exists("ylim")) ylim=c(-100,500)
    #if (!exists("pch")) pch=20
    #if (!exists("cex")) cex=2
    plot(time_vector,rad_balance,type="l",lwd=2,col="gray50",main="Surface Energy Balance",ylab="surface energy balance fluxes",xlab="index",...)
    points(time_vector,seb_balance,type="p",lwd=3,col=1,pch=20)
    points(time_vector,sh,type="p",lwd=2,col=rgb(0.4,0,0.5,0.5),pch=3)
    points(time_vector,lh,type="p",lwd=2,col=rgb(0,0.7,0,0.5),pch=4)
    points(time_vector,gh,type="l",lwd=2,col="orange3")
    abline(h=0,lty=2)
    legend("topright",legend=c("R","GH","SH","LH","Res"),col=c("gray50","orange3","purple","green2",1),lwd=c(2,2,2,2,3),lty=c(1,1,0,0,0),pch=c(NA,NA,3,4,20),bg="white")
    plot(rad_balance-gh,sh+lh,col=rgb(0,0,0,0.4),pch=20,cex=2,main="Surface Energy Balance Closure",xlab="R-G",ylab="SH+LH",...)
    y=sh+lh
    x=rad_balance-gh
    fit=lm(y ~ x)
    if (print_fit==TRUE) print(summary(fit))
    abline(fit,lwd=2,col=2,lty=2)
    abline(0,1,lwd=2,lty=1)
    grid()
    legend("topleft",legend=c("1:1","linear regression"),col=c(1,2),lty=c(1,2),lwd=2)
    if (print_fit==TRUE) print(paste("mean closure ratio: ", round(mean(cr,na.rm=TRUE),2)))
    if (print_fit==TRUE) print(paste("mean residual flux: ", round(mean(seb_balance,na.rm=TRUE)),"W/m^2"))
}